# PythonCSV2HTML
A simple text-basec converter for converting 2 types of csv files into html-ready format.
Prerequisite packages: pip install pandas, pip install csv (if not already installed)

Credits: Misho V 2022,Pandas Package Team github.com/pandas-dev/pandas
